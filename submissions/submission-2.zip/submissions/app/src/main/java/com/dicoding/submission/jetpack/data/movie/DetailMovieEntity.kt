package com.dicoding.submission.jetpack.data.movie

data class DetailMovieEntity(
        val id: String,
        val homepage: String,
        val title: String,
        val overview: String,
        val status: String,
)